<!DOCTYPE html>
<html>
<head>
	<title>Tutorial Membuat CRUD Pada Laravel</title>
</head>
<body>

	<h2>Edit</h2>
	<h3>Data Pegawai</h3>

	<a href="/pegawai"> Kembali</a>
	
	<br/>
	<br/>

	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="/pegawai/update" method="post">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="id" value="<?php echo e($p->id_pgw); ?>"> <br/>
		Nama <input type="text" required="required" name="nama" value="<?php echo e($p->nama_pgw); ?>"> <br/>
		Jabatan <input type="text" required="required" name="jabatan" value="<?php echo e($p->id_jabatan_pgw); ?>"> <br/>
		Umur <input type="number" required="required" name="umur" value="<?php echo e($p->umur_pgw); ?>"> <br/>
		Alamat <textarea required="required" name="alamat"><?php echo e($p->alamat_pgw); ?></textarea> <br/>
		<input type="submit" value="Simpan Data">
	</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		

</body>
</html>