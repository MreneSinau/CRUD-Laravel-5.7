<!DOCTYPE html>
<html>
<head>
	<title>Tutorial Membuat CRUD Pada Laravel</title>
</head>
<body>

	<h2>Tampil Data</h2>
	<h3>Data Pegawai</h3>

	<a href="/pegawai/tambah"> + Tambah Pegawai Baru</a>
	
	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>Nama</th>
			<th>Jabatan</th>
			<th>Umur</th>
			<th>Alamat</th>
			<th>Opsi</th>
		</tr>
		<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($p->nama_pgw); ?></td>
			<td><?php echo e($p->id_jabatan_pgw); ?></td>
			<td><?php echo e($p->umur_pgw); ?></td>
			<td><?php echo e($p->alamat_pgw); ?></td>
			<td>
				<a href="/pegawai/edit/<?php echo e($p->id_pgw); ?>">Edit</a>
				|
				<a href="/pegawai/hapus/<?php echo e($p->id_pgw); ?>">Hapus</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>


</body>
</html>