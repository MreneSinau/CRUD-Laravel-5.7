<!DOCTYPE html>
<html>
<head>
	<title>Tutorial Membuat CRUD Pada Laravel</title>
</head>
<body>

	<h2>Tampil Data</h2>
	<h3>Data Pegawai</h3>

	<a href="/pegawai/tambah"> + Tambah Pegawai Baru</a>
	
	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>Nama</th>
			<th>Jabatan</th>
			<th>Umur</th>
			<th>Alamat</th>
			<th>Opsi</th>
		</tr>
		@foreach($pegawai as $p)
		<tr>
			<td>{{ $p->nama_pgw }}</td>
			<td>{{ $p->id_jabatan_pgw }}</td>
			<td>{{ $p->umur_pgw }}</td>
			<td>{{ $p->alamat_pgw }}</td>
			<td>
				<a href="/pegawai/edit/{{ $p->id_pgw }}">Edit</a>
				|
				<a href="/pegawai/hapus/{{ $p->id_pgw }}">Hapus</a>
			</td>
		</tr>
		@endforeach
	</table>


</body>
</html>